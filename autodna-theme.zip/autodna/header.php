<?php
/**
 * The header: document head, preloader slot, opening body.
 *
 * @package AutoDNA
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'home loading' ); ?>>
<?php wp_body_open(); ?>
