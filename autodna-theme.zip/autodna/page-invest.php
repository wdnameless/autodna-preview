<?php
/**
 * Template Name: AutoDNA — Flip
 *
 * @package AutoDNA
 */

get_header();
?>


<div class="preloader" id="preloader" aria-hidden="true">
  <img class="preloader__art" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/preloader.svg" alt="AutoDNA">
  <div class="preloader__bar"><span></span></div>
</div>

<header class="head">
  <div class="shell head__row">
    <a class="head__mark" href="index.html" aria-label="AutoDNA home"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/logo-mark.png" alt="AutoDNA"></a>
    <button class="head__burger" type="button" data-menu-open aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>
  </div>
</header>

<nav class="drawer" id="drawer" aria-hidden="true" aria-label="Site">
  <div class="drawer__panel">
    <div class="drawer__top">
      <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/logo-mark.png" alt="" class="drawer__mark">
      <button class="drawer__close" type="button" data-menu-close aria-label="Close menu">✕ CLOSE</button>
    </div>
    <ul class="drawer__list">
      <li><a href="index.html">Who We Are</a></li>
      <li><a href="index.html#why">Why AutoDNA</a></li>
      <li><a href="index.html#compare">Price Comparison</a></li>
      <li><a href="index.html#services">Our Services</a></li>
      <li><a href="skipthedealer.html">SkipTheDealer</a></li>
      <li><a href="invest.html" aria-current="page">AutoDNA Flip</a></li>
      <li><a href="service.html">AutoDNA Service</a></li>
    </ul>
    <div class="drawer__foot">
      <a href="mailto:info@autodna.com">info@autodna.com</a>
      <a href="tel:+14033128306">+1 (403) 312-8306</a>
      <span>730 2 Ave SW, Calgary, T2P 1R8</span>
    </div>
  </div>
</nav>

<main>

  <!-- HERO — photo with the 196px headline at y61, the $2,000 line at y241 -->
  <section class="ih">
    <div class="ih__scene">
      <img class="ih__photo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/invest-hero.jpg" alt="">
      <h1 class="ih__title">Invest in cars.</h1>
      <p class="ih__earn">Earn from <em>$2,000</em><br>on each vehicle.</p>

      <p class="ih__lede">We buy, repair,<br>and sell cars —<br>you earn the profit.</p>
      <a class="ih__cta" href="#quote">Become an investor</a>

      <ul class="ih__facts">
        <li>Tangible assets</li>
        <li>Up to 40% ROI</li>
        <li>Lower risk</li>
      </ul>
    </div>
  </section>

  <!-- how it works — four steps -->
  <section class="section ihow" id="how">
    <div class="shell">
      <h2 class="outline ihow__word">How It <span>Works</span></h2>
      <div class="ihow__grid">
        <article class="marks">
          <span class="ihow__step">Step 1</span>
          <h3>Investment Plan &amp; Start</h3>
          <p>The investor meets with us and receives a detailed action plan — how exactly we buy, repair and sell cars, and what return to expect.</p>
          <p>After reviewing the plan, the investor contributes funds with a full understanding of the process.</p>
          <b>Goal: full clarity and confidence before investing.</b>
        </article>
        <article class="marks">
          <span class="ihow__step">Step 2</span>
          <h3>Car Purchase at Auction</h3>
          <p>We buy cars only from trusted, official auctions — minimizing risk at every stage. Each vehicle is checked before bidding.</p>
          <p>Our experienced team knows how to choose the right cars and avoid mistakes. If any issue occurs, we handle it.</p>
          <b>Goal: safe purchase with zero unnecessary risks.</b>
        </article>
        <article class="marks">
          <span class="ihow__step">Step 3</span>
          <h3>Repair &amp; Preparation for Sale</h3>
          <p>We work with our own service network and verified partners to restore each vehicle, keeping quality high and costs controlled.</p>
          <p>Thanks to our methods and local expertise, we can sell affordably for buyers while keeping strong margins.</p>
          <b>Goal: maximize value through quality and efficiency.</b>
        </article>
        <article class="marks">
          <span class="ihow__step">Step 4</span>
          <h3>Selling at Market Price</h3>
          <p>After full restoration, the car is listed for sale through our trusted sales channels.</p>
          <p>Our marketing and reputation help us close sales within days. Each sale generates transparent financial results.</p>
          <b>Goal: fast sale at fair market value.</b>
        </article>
      </div>
    </div>
  </section>

  <!-- profit examples -->
  <section class="section iprofit" id="profit">
    <div class="shell">
      <img class="iprofit__fleet" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/invest-fleet.jpg" alt="Cars sourced for the flip programme">
      <h2 class="outline iprofit__word">Profit Examples</h2>

      <div class="table-scroll">
        <table class="table">
          <thead>
            <tr><th>Investment Amount</th><th>Potential Profit</th><th>Number of Cars</th><th>Notes</th></tr>
          </thead>
          <tbody>
            <tr><td>$10,000</td><td class="hl">$2,500</td><td>1 car</td><td>Single car example</td></tr>
            <tr><td>$30,000</td><td class="hl">$6,000–$9,000</td><td>2–3 cars</td><td>Multiple cars per cycle</td></tr>
            <tr><td>$50,000</td><td class="hl">$8,000–$15,000 / mo</td><td>4–5 cars</td><td>Higher investment, more cars</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <!-- investor benefits -->
  <section class="section iben" id="benefits">
    <div class="shell">
      <h2 class="display iben__word">Investor Benefits</h2>
      <div class="iben__grid">
        <article class="marks"><h3>High Returns</h3><p>Earn 20–30% profit per deal, consistently and reliably.</p></article>
        <article class="marks"><h3>Reliable Investment</h3><p>A real, tangible business, not just “virtual opportunities.”</p></article>
        <article class="marks"><h3>All-Inclusive Service</h3><p>Save compared to dealer and Marketplace private seller prices.</p></article>
        <article class="marks"><h3>Fast Turnover</h3><p>Each investment cycle takes only about 1 month.</p></article>
        <article class="marks"><h3>Full Transparency</h3><p>Receive detailed reports and updates for every car.</p></article>
      </div>
    </div>
  </section>

  <!-- guarantee -->
  <section class="section igua" id="guarantee">
    <div class="shell">
      <h2 class="display igua__word">Guarantee &amp; Transparency</h2>

      <div class="igua__grid">
        <article class="marks"><h3>Official Auctions</h3><p>Reliable sourcing — we work only with trusted auctions like Copart, IAAI and ADESA.</p></article>
        <article class="marks"><h3>Cars in Top Condition</h3><p>Each vehicle is thoroughly inspected and restored if needed.</p></article>
        <article class="marks"><h3>Safe and Transparent</h3><p>No hidden costs, no surprises — you see everything.</p></article>
      </div>

      <div class="igua__grid igua__grid--three">
        <article class="marks"><h3>Complete Financial Reports</h3><p>Investor insight — you receive a clear breakdown of every transaction.</p></article>
        <article class="marks"><h3>Quality Assurance</h3><p>Every detail tracked — purchases, repair costs, inspections and sales are documented.</p></article>
        <article class="marks"><h3>Peace of Mind</h3><p>Cars in top condition — each vehicle is inspected and restored before sale.</p></article>
      </div>
    </div>
  </section>

  <!-- compare -->
  <section class="section icomp" id="compare">
    <div class="shell">
      <h2 class="outline icomp__word">Compare Your Options</h2>
      <div class="table-scroll">
        <table class="table">
          <thead><tr><th>Investment Type</th><th>Typical Return / Notes</th></tr></thead>
          <tbody>
            <tr><td>Bank</td><td>3–5% per year</td></tr>
            <tr><td>Cryptocurrency</td><td>Unpredictable</td></tr>
            <tr><td>Stocks</td><td>Long-term</td></tr>
            <tr class="hl"><td>AutoDNA Flip</td><td>20–30% per month — fast and concrete</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <!-- quote -->
  <section class="section iquote" id="quote">
    <div class="shell iquote__inner">
      <p class="kicker">Capital allocation</p>
      <h2 class="display iquote__word">Ready to Invest?</h2>
      <p class="body">Put your capital to work today. Profit — in 30 days.</p>

      <form data-quote novalidate>
        <div class="iquote__grid">
          <div class="field"><label for="i-name">Name</label><input id="i-name" name="name" type="text" required autocomplete="name" placeholder="Your name"><span class="field-error">Please enter your name</span></div>
          <div class="field"><label for="i-email">Email</label><input id="i-email" name="email" type="email" required autocomplete="email" placeholder="you@company.com"><span class="field-error">Please enter a valid email</span></div>
          <div class="field"><label for="i-phone">Phone</label><input id="i-phone" name="phone" type="text" required placeholder="+1 (403) 000-0000"><span class="field-error">Required</span></div>
          <div class="field"><label for="i-amount">Capital (CAD)</label><input id="i-amount" name="amount" type="text" required placeholder="$30,000"><span class="field-error">Required</span></div>
          <div class="field iquote__wide"><label for="i-message">Horizon / notes</label><textarea id="i-message" name="message" rows="3" placeholder="One cycle or a rolling portfolio?"></textarea></div>
        </div>
        <button type="submit" class="btn btn--solid iquote__submit">Submit a request</button>
        <div class="form-success">Thanks — an investment manager will send the current pipeline.</div>
      </form>
    </div>
  </section>

</main>

<footer class="foot" id="contact">
  <div class="shell">
    <div class="foot__grid">
      <div><h4>Contact us</h4><a href="mailto:info@autodna.com">info@autodna.com</a><a href="tel:+14033128306">+1 (403) 312-8306</a></div>
      <div><h4>Follow us</h4><div class="foot__social">
        <a href="https://instagram.com" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.2c3.2 0 3.6 0 4.9.1 1.2.1 1.8.3 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.1.4.3 1 .4 2.2.1 1.3.1 1.7.1 4.9s0 3.6-.1 4.9c-.1 1.2-.3 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.1-1 .3-2.2.4-1.3.1-1.7.1-4.9.1s-3.6 0-4.9-.1c-1.2-.1-1.8-.3-2.2-.4-.6-.2-1-.5-1.4-.9-.4-.4-.7-.8-.9-1.4-.1-.4-.3-1-.4-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.9c.1-1.2.3-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.1 1-.3 2.2-.4C8.4 2.2 8.8 2.2 12 2.2zm0 5.1a4.7 4.7 0 100 9.4 4.7 4.7 0 000-9.4zm0 7.7a3 3 0 110-6 3 3 0 010 6zm6-8a1.1 1.1 0 11-2.2 0 1.1 1.1 0 012.2 0z"/></svg></a>
        <a href="https://linkedin.com" target="_blank" rel="noopener" aria-label="LinkedIn"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 11-.02 5 2.5 2.5 0 01.02-5zM3 9h4v12H3zM9 9h3.8v1.7h.05c.53-1 1.83-2.05 3.77-2.05 4.03 0 4.78 2.65 4.78 6.1V21h-4v-5.4c0-1.29-.02-2.95-1.8-2.95-1.8 0-2.08 1.4-2.08 2.85V21H9z"/></svg></a>
        <a href="https://youtube.com" target="_blank" rel="noopener" aria-label="YouTube"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.6 7.2s-.2-1.4-.8-2c-.8-.8-1.7-.8-2.1-.9C16.9 4.1 12 4.1 12 4.1h-.1s-4.9 0-6.7.2c-.4.1-1.3.1-2.1.9-.6.6-.8 2-.8 2S2 8.8 2 10.5v1.6c0 1.7.2 3.3.2 3.3s.2 1.4.8 2c.8.8 1.8.8 2.2.9 1.8.2 6.8.2 6.8.2s4.9 0 6.7-.2c.4-.1 1.3-.1 2.1-.9.6-.6.8-2 .8-2s.2-1.6.2-3.3v-1.6c0-1.7-.2-3.3-.2-3.3zM9.8 14.3V8.6l6.1 2.9z"/></svg></a>
      </div></div>
      <div><h4>Find us</h4><p>Calgary, Alberta, Canada</p><p>730 2 Ave SW, Calgary, T2P1R8, Canada</p></div>
    </div>
    <p class="foot__copy">© 2025 AutoDNA Canada. All rights reserved.</p>
  </div>
</footer>



<?php
get_footer();
