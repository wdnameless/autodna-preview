<?php
/**
 * AutoDNA theme functions.
 *
 * @package AutoDNA
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AUTODNA_VERSION', '1.0.0' );

/**
 * Styles and scripts, in the order the layout needs them.
 */
function autodna_assets() {
	$uri = get_template_directory_uri();

	// fonts first: the CSS references the woff2 files by relative path
	wp_enqueue_style( 'autodna-base', $uri . '/assets/css/base.css', array(), AUTODNA_VERSION );
	wp_enqueue_style( 'autodna-site', $uri . '/assets/css/site.css', array( 'autodna-base' ), AUTODNA_VERSION );
	wp_enqueue_style( 'autodna-main', $uri . '/assets/css/main.css', array( 'autodna-site' ), AUTODNA_VERSION );
	wp_enqueue_style( 'autodna-services', $uri . '/assets/css/services.css', array( 'autodna-main' ), AUTODNA_VERSION );
	wp_enqueue_style( 'autodna-style', get_stylesheet_uri(), array( 'autodna-services' ), AUTODNA_VERSION );

	wp_enqueue_script( 'autodna-site', $uri . '/assets/js/site.js', array(), AUTODNA_VERSION, true );
	wp_enqueue_script( 'autodna-services', $uri . '/assets/js/services.js', array(), AUTODNA_VERSION, true );
	wp_enqueue_script( 'autodna-main', $uri . '/assets/js/main.js', array(), AUTODNA_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'autodna_assets' );

/**
 * Theme supports.
 */
function autodna_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'script', 'style' ) );
	add_theme_support( 'custom-logo', array( 'height' => 20, 'width' => 37, 'flex-width' => true ) );
}
add_action( 'after_setup_theme', 'autodna_setup' );

/**
 * The board's fixed copy belongs in the markup, but these helpers let an editor
 * override it without touching templates. Every value falls back to the design.
 */
function autodna_text( $key, $default ) {
	$value = get_theme_mod( 'autodna_' . $key, '' );
	return '' !== $value ? $value : $default;
}

/**
 * Preload the two fonts that paint above the fold.
 */
function autodna_preload_fonts() {
	$uri = get_template_directory_uri();
	printf(
		'<link rel="preload" href="%s/assets/fonts/HelveticaNeue-light.woff2" as="font" type="font/woff2" crossorigin>' . "\n",
		esc_url( $uri )
	);
	printf(
		'<link rel="preload" href="%s/assets/fonts/Orbitron-Variable.woff2" as="font" type="font/woff2" crossorigin>' . "\n",
		esc_url( $uri )
	);
}
add_action( 'wp_head', 'autodna_preload_fonts', 1 );

/**
 * Keep the preloader from flashing on every navigation: only the first visit gets it.
 */
function autodna_body_class( $classes ) {
	if ( isset( $_COOKIE['autodna_seen'] ) ) {
		$classes = array_diff( $classes, array( 'loading' ) );
	}
	return $classes;
}
add_filter( 'body_class', 'autodna_body_class' );
