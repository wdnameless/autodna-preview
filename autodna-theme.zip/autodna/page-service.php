<?php
/**
 * Template Name: AutoDNA — Service
 *
 * @package AutoDNA
 */

get_header();
?>


<div class="preloader" id="preloader" aria-hidden="true">
  <img class="preloader__art" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/preloader.svg" alt="AutoDNA">
  <div class="preloader__bar"><span></span></div>
</div>

<header class="head">
  <div class="shell head__row">
    <a class="head__mark" href="index.html" aria-label="AutoDNA home"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/logo-mark.png" alt="AutoDNA"></a>
    <button class="head__burger" type="button" data-menu-open aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>
  </div>
</header>

<nav class="drawer" id="drawer" aria-hidden="true" aria-label="Site">
  <div class="drawer__panel">
    <div class="drawer__top">
      <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/logo-mark.png" alt="" class="drawer__mark">
      <button class="drawer__close" type="button" data-menu-close aria-label="Close menu">✕ CLOSE</button>
    </div>
    <ul class="drawer__list">
      <li><a href="index.html">Who We Are</a></li>
      <li><a href="index.html#why">Why AutoDNA</a></li>
      <li><a href="index.html#compare">Price Comparison</a></li>
      <li><a href="index.html#services">Our Services</a></li>
      <li><a href="skipthedealer.html">SkipTheDealer</a></li>
      <li><a href="invest.html">AutoDNA Flip</a></li>
      <li><a href="service.html" aria-current="page">AutoDNA Service</a></li>
    </ul>
    <div class="drawer__foot">
      <a href="mailto:info@autodna.com">info@autodna.com</a>
      <a href="tel:+14033128306">+1 (403) 312-8306</a>
      <span>730 2 Ave SW, Calgary, T2P 1R8</span>
    </div>
  </div>
</nav>

<main>

  <!-- HERO — the board's collage: 135px headline over the facility photo -->
  <section class="sh">
    <div class="sh__scene">
      <img class="sh__photo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/service-hero.jpg" alt="">
      <h1 class="sh__title">The future of service</h1>
      <p class="sh__sub">is already here.</p>
      <p class="sh__word">service</p>
    </div>
  </section>

  <!-- intro copy -->
  <section class="section sintro">
    <div class="shell sintro__inner">
      <p class="kicker">Innovation. Technology. Trust.</p>
      <p class="sintro__body">AutoDNA Service is a next-generation automotive center, equipped with innovative technology, a modern minimalist and spotless interior, smart service systems, a skilled team, and much more.</p>
      <p class="sintro__small">It’s not just a service — it’s a modern automotive ecosystem that integrates telematics, robotics, and customer comfort.</p>
      <p class="display sintro__claim">The future of car service<br>begins in <em>Calgary.</em></p>
    </div>
  </section>

  <!-- ONE DNA — three services, switchable -->
  <section class="section sdna" id="services">
    <div class="shell" data-service-switcher>
      <h2 class="display sdna__word">One DNA.<br><span>Multiple services.</span></h2>

      <div class="sdna__tabs" role="tablist">
        <button type="button" class="sdna__tab is-active" data-service-tab="shop" role="tab" aria-selected="true">SkipTheShop</button>
        <button type="button" class="sdna__tab" data-service-tab="drivecare" role="tab" aria-selected="false">DriveCarePlan</button>
        <button type="button" class="sdna__tab" data-service-tab="paintbot" role="tab" aria-selected="false">PaintBot</button>
      </div>

      <!-- SkipTheShop -->
      <div class="sdna__panel is-active" data-service-panel="shop" role="tabpanel">
        <h3 class="sdna__name">SkipTheShop</h3>
        <p class="sdna__tag">Your car goes to service. You don’t.</p>
        <img class="sdna__shot" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/clean/service/skiptheshop-triptych.jpg" alt="Concierge pickup and return">
        <p class="sdna__copy">A new format of car service — where you don’t go to the shop. Our technician picks up your car, completes all necessary work, and brings it back to you.</p>
        <p class="sdna__note">Fast. No lines. No wasted time.</p>
      </div>

      <!-- DriveCarePlan -->
      <div class="sdna__panel" data-service-panel="drivecare" role="tabpanel">
        <h3 class="sdna__name">DriveCarePlan</h3>
        <p class="sdna__tag">See problems before they happen.</p>
        <img class="sdna__shot" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/service-obd.jpg" alt="OBD II telematics module">
        <p class="sdna__copy">It’s a system with an OBD II module that combines vehicle monitoring, analytics, and preventive maintenance.</p>
        <p class="sdna__copy">It remotely tracks each car’s condition — mileage, fuel consumption, ECU errors, temperature, and load — and automatically reminds you when it’s time for service, diagnostics, or refuelling.</p>
      </div>

      <!-- PaintBot -->
      <div class="sdna__panel" data-service-panel="paintbot" role="tabpanel">
        <h3 class="sdna__name">PaintBot</h3>
        <p class="sdna__tag">Reinventing body shop painting.</p>
        <img class="sdna__shot" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/service-paintbot.jpg" alt="PaintBot industrial painting robot">
        <p class="sdna__copy">The first body shop in Calgary to use an industrial robot for car painting. The robot paints with precision beyond human capability.</p>
        <p class="sdna__copy">A technology once reserved for major automotive manufacturers is now available in our service — for private clients.</p>
      </div>

      <p class="sdna__official">Explore the future of car care — learn more on our AutoDNA Service official site: <span>AutoDnaService</span></p>
    </div>
  </section>

  <!-- team + contact -->
  <section class="section steam">
    <div class="shell">
      <div class="marks steam__card">
        <h2 class="steam__title">Inside the Mind<br>of AutoDNA.</h2>
        <img class="steam__photo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/clean/service/team-members.jpg" alt="The AutoDNA service team">
        <div class="steam__cols">
          <p>We believe <em>great service starts with clarity</em> — in thinking, in process, in space.</p>
          <p>And it’s born where great people work together with one clear vision — <em>to redefine car care.</em></p>
        </div>
      </div>

      <p class="display steam__claim">They’re the reason<br>AutoDNA feels different.</p>
      <p class="display steam__sub">Every face here stands for<br>reliability, innovation, and trust.</p>

      <a class="btn steam__cta" href="index.html#contact">Contact with us</a>
    </div>
  </section>

</main>

<footer class="foot" id="contact">
  <div class="shell">
    <div class="foot__grid">
      <div><h4>Contact us</h4><a href="mailto:info@autodna.com">info@autodna.com</a><a href="tel:+14033128306">+1 (403) 312-8306</a></div>
      <div><h4>Follow us</h4><div class="foot__social">
        <a href="https://instagram.com" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.2c3.2 0 3.6 0 4.9.1 1.2.1 1.8.3 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.1.4.3 1 .4 2.2.1 1.3.1 1.7.1 4.9s0 3.6-.1 4.9c-.1 1.2-.3 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.1-1 .3-2.2.4-1.3.1-1.7.1-4.9.1s-3.6 0-4.9-.1c-1.2-.1-1.8-.3-2.2-.4-.6-.2-1-.5-1.4-.9-.4-.4-.7-.8-.9-1.4-.1-.4-.3-1-.4-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.9c.1-1.2.3-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.1 1-.3 2.2-.4C8.4 2.2 8.8 2.2 12 2.2zm0 5.1a4.7 4.7 0 100 9.4 4.7 4.7 0 000-9.4zm0 7.7a3 3 0 110-6 3 3 0 010 6zm6-8a1.1 1.1 0 11-2.2 0 1.1 1.1 0 012.2 0z"/></svg></a>
        <a href="https://linkedin.com" target="_blank" rel="noopener" aria-label="LinkedIn"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 11-.02 5 2.5 2.5 0 01.02-5zM3 9h4v12H3zM9 9h3.8v1.7h.05c.53-1 1.83-2.05 3.77-2.05 4.03 0 4.78 2.65 4.78 6.1V21h-4v-5.4c0-1.29-.02-2.95-1.8-2.95-1.8 0-2.08 1.4-2.08 2.85V21H9z"/></svg></a>
        <a href="https://youtube.com" target="_blank" rel="noopener" aria-label="YouTube"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.6 7.2s-.2-1.4-.8-2c-.8-.8-1.7-.8-2.1-.9C16.9 4.1 12 4.1 12 4.1h-.1s-4.9 0-6.7.2c-.4.1-1.3.1-2.1.9-.6.6-.8 2-.8 2S2 8.8 2 10.5v1.6c0 1.7.2 3.3.2 3.3s.2 1.4.8 2c.8.8 1.8.8 2.2.9 1.8.2 6.8.2 6.8.2s4.9 0 6.7-.2c.4-.1 1.3-.1 2.1-.9.6-.6.8-2 .8-2s.2-1.6.2-3.3v-1.6c0-1.7-.2-3.3-.2-3.3zM9.8 14.3V8.6l6.1 2.9z"/></svg></a>
      </div></div>
      <div><h4>Find us</h4><p>Calgary, Alberta, Canada</p><p>730 2 Ave SW, Calgary, T2P1R8, Canada</p></div>
    </div>
    <p class="foot__copy">© 2025 AutoDNA Canada. All rights reserved.</p>
  </div>
</footer>




<?php
get_footer();
