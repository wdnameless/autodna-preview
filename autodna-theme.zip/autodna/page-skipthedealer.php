<?php
/**
 * Template Name: AutoDNA — SkipTheDealer
 *
 * @package AutoDNA
 */

get_header();
?>


<div class="preloader" id="preloader" aria-hidden="true">
  <img class="preloader__art" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/preloader.svg" alt="AutoDNA">
  <div class="preloader__bar"><span></span></div>
</div>

<header class="head">
  <div class="shell head__row">
    <a class="head__mark" href="index.html" aria-label="AutoDNA home"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/logo-mark.png" alt="AutoDNA"></a>
    <button class="head__burger" type="button" data-menu-open aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>
  </div>
</header>

<nav class="drawer" id="drawer" aria-hidden="true" aria-label="Site">
  <div class="drawer__panel">
    <div class="drawer__top">
      <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/logo-mark.png" alt="" class="drawer__mark">
      <button class="drawer__close" type="button" data-menu-close aria-label="Close menu">✕ CLOSE</button>
    </div>
    <ul class="drawer__list">
      <li><a href="index.html">Who We Are</a></li>
      <li><a href="index.html#why">Why AutoDNA</a></li>
      <li><a href="index.html#compare">Price Comparison</a></li>
      <li><a href="index.html#services">Our Services</a></li>
      <li><a href="index.html#facts">Facts &amp; Figures</a></li>
      <li><a href="skipthedealer.html" aria-current="page">SkipTheDealer</a></li>
      <li><a href="invest.html">AutoDNA Flip</a></li>
      <li><a href="service.html">AutoDNA Service</a></li>
    </ul>
    <div class="drawer__foot">
      <a href="mailto:info@autodna.com">info@autodna.com</a>
      <a href="tel:+14033128306">+1 (403) 312-8306</a>
      <span>730 2 Ave SW, Calgary, T2P 1R8</span>
    </div>
  </div>
</nav>

<main>

  <!-- HERO — the board's own composition: photo band, claim, wordmark, then two
       copy columns and the small CTA, all inside the same 809px block -->
  <section class="dh">
    <div class="dh__scene">
      <img class="dh__photo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/dealer-hero.jpg" alt="">
      <p class="dh__claim">Buy cars up to <em>40% cheaper</em></p>
      <h1 class="dh__word">SkipTheDealer</h1>

      <p class="dh__left">You pay the <em>real</em><br>price, not someone<br>else’s markup.</p>
      <span class="dh__diag" aria-hidden="true"></span>
      <p class="dh__right">No showrooms, no<br>fancy words. <em>Just</em><br>cheaper cars.</p>
      <a class="dh__cta" href="#how">See how it works</a>
    </div>
  </section>

  <!-- scenarios -->
  <section class="section dscen">
    <div class="shell">
      <p class="dscen__lede">Imagine buying a<br>Dealers are out of the game.<br>Now it’s your turn.</p>
      <p class="dscen__sub">Customers can get a car 30–40% cheaper than the market price. There are two main scenarios:</p>

      <div class="dscen__grid">
        <article>
          <h3>1.Buy and profit</h3>
          <p>A customer buys a car for $10,000, while the market price is $14,000–$15,000. They immediately gain $4,000–$5,000 in value.</p>
        </article>
        <article>
          <h3>2. Drive without losing</h3>
          <p>A customer keeps the car for 2–3 years. During this time, the market price might drop from $15,000 to $7,000–$8,000 — but since they bought it for $10,000, the loss is zero.</p>
        </article>
      </div>

      <p class="dscen__claim">With SkipTheDealer, customers either profit or minimize losses to zero.</p>
    </div>
  </section>

  <!-- how it works: four steps, switchable -->
  <section class="section dhow" id="how">
    <div class="shell" data-step-switcher>
      <h2 class="outline dhow__word">How It <span>Works</span></h2>

      <div class="dhow__tabs" role="tablist">
        <button type="button" class="dhow__tab is-active" data-step-tab="1" role="tab" aria-selected="true">Step 1</button>
        <button type="button" class="dhow__tab" data-step-tab="2" role="tab" aria-selected="false">Step 2</button>
        <button type="button" class="dhow__tab" data-step-tab="3" role="tab" aria-selected="false">Step 3</button>
        <button type="button" class="dhow__tab" data-step-tab="4" role="tab" aria-selected="false">Step 4</button>
      </div>

      <div class="dhow__panel is-active" data-step-panel="1" role="tabpanel">
        <h3>Step 1. Introduction &amp; Car Selection</h3>
        <p>You tell us about your dream car — make, model, year, body type, features, and budget.</p>
        <p class="dhow__note">At this stage, you immediately receive an approximate financial overview:</p>
        <div class="dhow__four">
          <div><b>Approximate purchase price at auction</b><span>Estimated cost to buy the car at auction.</span></div>
          <div><b>Repair costs</b><span>Expected expenses to fix any damage.</span></div>
          <div><b>Additional expenses</b><span>Inspection, diagnostics, registration, fees.</span></div>
          <div><b>Final “turnkey” price</b><span>Total cost to have the car ready to drive.</span></div>
        </div>
        <p class="dhow__claim">We always calculate the total with your expected savings in mind—your car ends up 30–40% cheaper than dealer or marketplace prices.</p>
        <div class="dhow__two">
          <p>Example: if the market price of a car is $20,000, we typically buy it at auction for around $10,000. Then we add repair, inspection, fees, and registration costs — and the final price comes to about $14,000. As a result, you save $6,000 compared to the market.</p>
          <p>Thanks to this transparency, even before buying you know: - how much the car itself will cost, - what the repair and documentation expenses will be, - what the total final price is, - and how much money you’ll actually save.</p>
        </div>
      </div>

      <div class="dhow__panel" data-step-panel="2" role="tabpanel">
        <h3>Step 2. Daily Selection &amp; Auctions</h3>
        <p>Every day, we select several cars that match your requirements:</p>
        <div class="dhow__four">
          <div><b>Daily selection</b><span>We pick cars that match your requirements.</span></div>
          <div><b>Detailed analysis</b><span>You get photos, history, and estimated costs for each car.</span></div>
          <div><b>Your confirmation</b><span>You choose which cars meet your needs.</span></div>
          <div><b>Auction bidding</b><span>We place bids on the selected cars.</span></div>
        </div>
        <p class="dhow__claim">Auctions are competitive—sometimes a car is not won immediately. We keep searching until we secure a vehicle within your budget, usually within a week.</p>
      </div>

      <div class="dhow__panel" data-step-panel="3" role="tabpanel">
        <h3>Step 3. Purchase &amp; Restoration</h3>
        <p>After winning the auction, your car is delivered to our service center for a full inspection:</p>
        <div class="dhow__two">
          <p>If the car is intact → we perform a complete check and fix all technical issues.</p>
          <p>If damaged (collision, hail, cosmetic) → we do bodywork, painting, and full repairs.</p>
        </div>
        <p class="dhow__claim">The result: a car in perfect condition.</p>
      </div>

      <div class="dhow__panel" data-step-panel="4" role="tabpanel">
        <h3>Step 4. Inspection &amp; Documents</h3>
        <div class="dhow__two">
          <p>If the car is clean (active status) → you can register it immediately.</p>
          <p>If the car has salvage status → it undergoes an AMVIC inspection and gets rebuilt status.</p>
        </div>
        <p class="dhow__claim">In all cases, you receive official documents confirming the car’s safety and functionality.</p>
      </div>
    </div>
  </section>

  <!-- real savings: three cars, then the four-column table -->
  <section class="section dsav" id="savings">
    <div class="shell">
      <img class="dsav__cars" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/dealer-savings-cars.jpg" alt="Delivered Honda Civic, VW Tiguan and Hyundai Elantra">
      <h2 class="display dsav__word">Real Savings<br>on Every Car</h2>

      <div class="table-scroll dsav__table">
        <table class="table">
          <thead>
            <tr><th>Car (Year &amp; Model)</th><th>Dealer Price</th><th>SkipTheDealer Price</th><th>You Save</th></tr>
          </thead>
          <tbody>
            <tr><td>2019 Honda Civic</td><td>$18,900</td><td class="hl">$13,200</td><td class="hl">$5,700</td></tr>
            <tr><td>2020 VW Tiguan</td><td>$26,500</td><td class="hl">$18,900</td><td class="hl">$7,600</td></tr>
            <tr><td>2021 Hyundai Elantra</td><td>$21,700</td><td class="hl">$15,200</td><td class="hl">$6,500</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <!-- why it works -->
  <section class="section dwhy">
    <div class="shell">
      <h2 class="display dwhy__word">Why It Works</h2>
      <div class="dwhy__grid">
        <article class="marks"><h3>30–40% cheaper</h3><p>Save compared to dealer and Marketplace private seller prices.</p></article>
        <article class="marks"><h3>Full inspection &amp; safety guaranteed</h3><p>Every car goes through a full diagnostic and AMVIC inspection.</p></article>
        <article class="marks"><h3>Same market, zero dealer markup</h3><p>Dealers buy from the same auctions and resell for more. We buy for you at dealer prices.</p></article>
        <article class="marks"><h3>Access to exclusive auctions</h3><p>We represent you at closed auctions regular buyers can’t access.</p></article>
        <article class="marks"><h3>Long-term financial benefit</h3><p>In 2–3 years, you can resell your car for nearly the same price — no losses.</p></article>
      </div>
    </div>
  </section>

  <!-- friends offer -->
  <section class="section dfriends">
    <div class="shell">
      <div class="marks dfriends__box">
        <h2>Your friends<br>are our friends!</h2>
        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/family.jpg" alt="AutoDNA owners">
        <p>Your friends and family can enjoy a 30% discount on every second order.<br>And when they make their first order — you’ll get 30% off too!</p>
      </div>
    </div>
  </section>

  <!-- quote -->
  <section class="section dquote" id="quote">
    <div class="shell dquote__inner">
      <p class="kicker">Request a quote</p>
      <h2 class="display dquote__word">Not sure where to start?</h2>

      <form data-quote novalidate>
        <div class="dquote__grid">
          <div class="field"><label for="q-name">Name</label><input id="q-name" name="name" type="text" required autocomplete="name" placeholder="Your name"><span class="field-error">Please enter your name</span></div>
          <div class="field"><label for="q-make">Make</label><input id="q-make" name="make" type="text" required placeholder="Toyota"><span class="field-error">Required</span></div>
          <div class="field"><label for="q-model">Model</label><input id="q-model" name="model" type="text" placeholder="Corolla"><span class="field-error">Required</span></div>
          <div class="field"><label for="q-year">Year</label><input id="q-year" name="year" type="text" inputmode="numeric" placeholder="2021"><span class="field-error">Required</span></div>
          <div class="field"><label for="q-budget">Budget</label><input id="q-budget" name="budget" type="text" required placeholder="$18,000"><span class="field-error">Required</span></div>
          <div class="field"><label for="q-email">Email</label><input id="q-email" name="email" type="email" required autocomplete="email" placeholder="you@email.com"><span class="field-error">Please enter a valid email</span></div>
          <div class="field dquote__wide"><label for="q-message">Message</label><textarea id="q-message" name="message" rows="3" placeholder="Anything we should know?"></textarea></div>
        </div>
        <button type="submit" class="btn btn--solid dquote__submit">Submit a request</button>
        <div class="form-success">Thanks — we’ll come back within one business day.</div>
      </form>
    </div>
  </section>

  <!-- closing + team -->
  <section class="section">
    <div class="shell">
      <p class="display dclose__line">Save up to $10,000 on your next car?</p>
      <p class="display dclose__alt">— It’s real.</p>
      <div class="dclose__grid">
        <h2 class="display dclose__word">we<br>don’t<br><span>just</span><br>sell<br>cars.</h2>
        <div>
          <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/family.jpg" alt="The AutoDNA team">
          <p class="dclose__text">We’re building a community where every customer gets more than they expect.</p>
        </div>
      </div>
    </div>
  </section>

</main>

<footer class="foot" id="contact">
  <div class="shell">
    <div class="foot__grid">
      <div><h4>Contact us</h4><a href="mailto:info@autodna.com">info@autodna.com</a><a href="tel:+14033128306">+1 (403) 312-8306</a></div>
      <div><h4>Follow us</h4><div class="foot__social">
        <a href="https://instagram.com" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.2c3.2 0 3.6 0 4.9.1 1.2.1 1.8.3 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.1.4.3 1 .4 2.2.1 1.3.1 1.7.1 4.9s0 3.6-.1 4.9c-.1 1.2-.3 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.1-1 .3-2.2.4-1.3.1-1.7.1-4.9.1s-3.6 0-4.9-.1c-1.2-.1-1.8-.3-2.2-.4-.6-.2-1-.5-1.4-.9-.4-.4-.7-.8-.9-1.4-.1-.4-.3-1-.4-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.9c.1-1.2.3-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.1 1-.3 2.2-.4C8.4 2.2 8.8 2.2 12 2.2zm0 5.1a4.7 4.7 0 100 9.4 4.7 4.7 0 000-9.4zm0 7.7a3 3 0 110-6 3 3 0 010 6zm6-8a1.1 1.1 0 11-2.2 0 1.1 1.1 0 012.2 0z"/></svg></a>
        <a href="https://linkedin.com" target="_blank" rel="noopener" aria-label="LinkedIn"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 11-.02 5 2.5 2.5 0 01.02-5zM3 9h4v12H3zM9 9h3.8v1.7h.05c.53-1 1.83-2.05 3.77-2.05 4.03 0 4.78 2.65 4.78 6.1V21h-4v-5.4c0-1.29-.02-2.95-1.8-2.95-1.8 0-2.08 1.4-2.08 2.85V21H9z"/></svg></a>
        <a href="https://youtube.com" target="_blank" rel="noopener" aria-label="YouTube"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M21.6 7.2s-.2-1.4-.8-2c-.8-.8-1.7-.8-2.1-.9C16.9 4.1 12 4.1 12 4.1h-.1s-4.9 0-6.7.2c-.4.1-1.3.1-2.1.9-.6.6-.8 2-.8 2S2 8.8 2 10.5v1.6c0 1.7.2 3.3.2 3.3s.2 1.4.8 2c.8.8 1.8.8 2.2.9 1.8.2 6.8.2 6.8.2s4.9 0 6.7-.2c.4-.1 1.3-.1 2.1-.9.6-.6.8-2 .8-2s.2-1.6.2-3.3v-1.6c0-1.7-.2-3.3-.2-3.3zM9.8 14.3V8.6l6.1 2.9z"/></svg></a>
      </div></div>
      <div><h4>Find us</h4><p>Calgary, Alberta, Canada</p><p>730 2 Ave SW, Calgary, T2P1R8, Canada</p></div>
    </div>
    <p class="foot__copy">© 2025 AutoDNA Canada. All rights reserved.</p>
  </div>
</footer>




<?php
get_footer();
