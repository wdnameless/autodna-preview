<?php
/**
 * The footer.
 *
 * @package AutoDNA
 */
?>
<footer class="foot" id="contact">
    <div class="shell">
      <div class="foot__grid">
        <div class="foot__col foot__col--contact">
          <h3>Contact us</h3>
          <a href="tel:+14033128306">+1 (403) 312-8306</a>
          <a href="mailto:info@autodna.com">info@autodna.com</a>
        </div>

        <div class="foot__col">
          <h3>Follow us</h3>
          <div class="foot__social">
            <a href="#" aria-label="Facebook"><svg viewBox="0 0 24 24"><path d="M14 9h3V6h-3c-2.2 0-4 1.8-4 4v2H8v3h2v7h3v-7h3l1-3h-4v-2c0-.6.4-1 1-1z"/></svg></a>
            <a href="#" aria-label="X"><svg viewBox="0 0 24 24"><path d="M17.5 3h3l-6.6 7.6L21.8 21h-6.1l-4.8-6.2L5.4 21h-3l7-8.1L2.6 3h6.2l4.3 5.7L17.5 3zm-1.1 16h1.7L7.7 4.7H5.9L16.4 19z"/></svg></a>
            <a href="#" aria-label="Instagram"><svg viewBox="0 0 24 24"><path d="M12 7.5A4.5 4.5 0 1 0 16.5 12 4.5 4.5 0 0 0 12 7.5zm0 7.4a2.9 2.9 0 1 1 2.9-2.9 2.9 2.9 0 0 1-2.9 2.9zM17 3H7a4 4 0 0 0-4 4v10a4 4 0 0 0 4 4h10a4 4 0 0 0 4-4V7a4 4 0 0 0-4-4zm2.4 14a2.4 2.4 0 0 1-2.4 2.4H7A2.4 2.4 0 0 1 4.6 17V7A2.4 2.4 0 0 1 7 4.6h10A2.4 2.4 0 0 1 19.4 7zm-2-11.3a1 1 0 1 0 1 1 1 1 0 0 0-1-1z"/></svg></a>
          </div>
        </div>

        <div class="foot__col foot__col--find">
          <h3>Find us</h3>
          <p>730 2 Ave SW,<br>Calgary, T2P1R8,<br>Canada</p>
        </div>
      </div>

      <p class="foot__legal">© 2025 AutoDNA Canada. All rights reserved.</p>
    </div>
  </footer>
<?php wp_footer(); ?>
</body>
</html>
