<?php
/**
 * Template Name: AutoDNA — Home
 * Description: The main board, built 1:1 from Figma (main.svg / Menu.svg).
 *
 * @package AutoDNA
 */

get_header();
?>

<!-- preloader: the board's own artwork, held 2.5s -->
<div class="preloader" id="preloader" aria-hidden="true">
  <picture class="preloader__art">
    <source media="(max-width: 640px)" srcset="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/preloader-mobile.svg">
    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/preloader.svg" alt="AutoDNA">
  </picture>
  <div class="preloader__bar"><span></span></div>
</div>

<main>
<!-- ══ 1. HERO — Menu.svg: triptych, THE GENETIC CODE, explore rail ══ -->
  <section class="hero" id="home">
    <div class="hero__outline" aria-hidden="true"></div>

    <a class="hero__mark" href="#home" aria-label="AutoDNA">
      <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/logo-mark.svg" alt="AutoDNA" width="37" height="20">
    </a>

    <button class="hero__burger" id="burger" data-menu-open aria-label="Open menu" aria-expanded="false" aria-controls="drawer">
      <span></span><span></span><span></span>
    </button>

    <!-- the three service links, with the board's bent connectors -->
    <div class="hero__rail" aria-label="Explore">
      <svg class="hero__wires" viewBox="0 0 265 210" preserveAspectRatio="none" aria-hidden="true">
        <path class="wire" d="M0 49.815H150.71L191.12 0.352H265.24"/>
        <path class="wire" d="M0 75.186H150.7L191.12 124.649H265.24"/>
        <path class="wire" d="M0 210.376H150.7L191.12 160.912H265.24"/>
        <path class="head" d="M257.4 6.4L265.24 0.352L257.4 -5.6"/>
        <path class="head" d="M257.4 130.7L265.24 124.649L257.4 118.6"/>
        <path class="head" d="M257.4 167L265.24 160.912L257.4 154.8"/>
      </svg>

      <a class="hero__link hero__link--1" href="<?php echo esc_url( home_url('/skipthedealer/') ); ?>"><em>Explore</em><span>SkipTheDealer</span></a>
      <a class="hero__link hero__link--2" href="<?php echo esc_url( home_url('/invest/') ); ?>"><span>AutoDNA</span><span>Flip</span></a>
      <a class="hero__link hero__link--3" href="<?php echo esc_url( home_url('/service/') ); ?>"><span>AutoDNA Service</span></a>
    </div>

    <!-- the full menu, opened by the hamburger -->
    <div class="hero__drawer" id="drawer" aria-hidden="true">
      <nav aria-label="Main menu">
          <span class="corner-mark" aria-hidden="true"></span>
          <span class="corner-mark" aria-hidden="true"></span>
          <span class="corner-mark" aria-hidden="true"></span>
          <span class="corner-mark" aria-hidden="true"></span>
          <a href="#home" class="is-current">Home
          <svg class="menu-arrow" viewBox="0 0 26 12" aria-hidden="true"><path d="M0 6h24M19 1l5 5-5 5"/></svg></a>
          <a href="#truth">Who We Are
          <svg class="menu-arrow" viewBox="0 0 26 12" aria-hidden="true"><path d="M0 6h24M19 1l5 5-5 5"/></svg></a>
          <a href="#values">Why AutoDNA
          <svg class="menu-arrow" viewBox="0 0 26 12" aria-hidden="true"><path d="M0 6h24M19 1l5 5-5 5"/></svg></a>
          <a href="#compare">Price Comparison
          <svg class="menu-arrow" viewBox="0 0 26 12" aria-hidden="true"><path d="M0 6h24M19 1l5 5-5 5"/></svg></a>
          <a href="#services">Our Services
          <svg class="menu-arrow" viewBox="0 0 26 12" aria-hidden="true"><path d="M0 6h24M19 1l5 5-5 5"/></svg></a>
          <a href="#stats">Facts &amp; Figures
          <svg class="menu-arrow" viewBox="0 0 26 12" aria-hidden="true"><path d="M0 6h24M19 1l5 5-5 5"/></svg></a>
          <a href="#parent">About AutoDNA
          <svg class="menu-arrow" viewBox="0 0 26 12" aria-hidden="true"><path d="M0 6h24M19 1l5 5-5 5"/></svg></a>
          <a href="#club">DNA Auto Club
          <svg class="menu-arrow" viewBox="0 0 26 12" aria-hidden="true"><path d="M0 6h24M19 1l5 5-5 5"/></svg></a>
          <a href="#contact">Contact
          <svg class="menu-arrow" viewBox="0 0 26 12" aria-hidden="true"><path d="M0 6h24M19 1l5 5-5 5"/></svg></a>
      </nav>
    </div>

    <div class="hero__inner">
      <div class="hero__center">
        <div class="hero__triptych">
          <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
          <img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/hero-triptych.webp" alt="A pickup, a Honda crossover and a Tesla side by side" fetchpriority="high">
        </div>

        <h1 class="hero__word">The genetic code</h1>

        <div class="hero__foot">
          <p class="hero__line">To your car</p>
          <p class="hero__line hero__line--right">Has <span>already</span> been found</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ══ 2. FOUR VALUES ═══════════════════════════════════════════════ -->
  <section class="values" id="values" aria-label="Why AutoDNA">
    <div class="values__halo" aria-hidden="true"></div>

    <div class="shell">
      <div class="values__grid">
        <article class="value-card">
          <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
          <h2 class="value-card__title">High quality</h2>
          <p class="value-card__text">A higher level of quality you can trust at an affordable price</p>
        </article>

        <article class="value-card">
          <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
          <h2 class="value-card__title">Wide choice</h2>
          <p class="value-card__text">A great selection of cars to match every lifestyle and need</p>
        </article>

        <article class="value-card">
          <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
          <h2 class="value-card__title">Save more</h2>
          <p class="value-card__text">A smarter way to save money without compromising on quality</p>
        </article>

        <article class="value-card">
          <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
          <h2 class="value-card__title">True value</h2>
          <p class="value-card__text">A real value that gives you confidence and satisfaction every time</p>
        </article>
      </div>
    </div>
  </section>

  <!-- ══ 3. IMAGINE — the claim and the fan of five ════════════════════ -->
  <section class="imagine">
    <div class="shell">
      <div class="imagine__head">
        <p class="sec-claim">Imagine buying a car from a dealer —</p>
        <p class="sec-claim sec-claim--accent">but paying the same price you’d pay a private seller.</p>
      </div>

      <div class="imagine__fan" aria-hidden="true">
        <svg viewBox="0 0 1240 160" preserveAspectRatio="none">
          <line x1="620" y1="0" x2="106"  y2="160"/>
          <line x1="620" y1="0" x2="420"  y2="160"/>
          <line x1="620" y1="0" x2="620"  y2="160"/>
          <line x1="620" y1="0" x2="820"  y2="160"/>
          <line x1="620" y1="0" x2="1134" y2="160"/>
        </svg>
      </div>

      <div class="imagine__grid">
        <div class="imagine__col">
          <h3>No surprises</h3>
          <p>No hidden fees. No surprises. We cover the GST ourselves.</p>
        </div>
        <div class="imagine__col">
          <h3>Affordable dealer prices</h3>
          <p>Buying from a dealer can be just as affordable as buying privately.</p>
        </div>
        <div class="imagine__col">
          <h3>Changing the game</h3>
          <p>Calgary has never seen this before. We put the customer first.</p>
        </div>
        <div class="imagine__col">
          <h3>Flexible options</h3>
          <p>Flexible financing and an extended warranty from our partners.</p>
        </div>
        <div class="imagine__col">
          <h3>Real value</h3>
          <p>Zero profit for us — just fair prices and peace of mind for you.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ══ 4. PRICE COMPARISON ═══════════════════════════════════════════ -->
  <section class="compare" id="compare">
    <div class="shell">
      <div class="compare__inner">
        <div>
          <img class="compare__car" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/carlears-car.webp" alt="Toyota Corolla Hatchback 2021" loading="lazy">
          <p class="compare__caption">Toyota Corolla Hatchback 2021</p>
        </div>

        <table class="compare__table">
          <caption class="visually-hidden">Price comparison between dealers, marketplace and AutoDNA</caption>
          <thead>
            <tr>
              <th scope="col"></th>
              <th scope="col">Dealers</th>
              <th scope="col">Marketplace</th>
              <th scope="col" class="is-win">AutoDNA</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Price</th>
              <td><span class="compare__price">$23,000 <small>+ GST</small></span></td>
              <td><span class="compare__price">$21,000 <small>(GST included)</small></span></td>
              <td class="is-win"><span class="compare__price">$21,000 <small>(GST included)</small></span></td>
            </tr>
            <tr>
              <th scope="row">Option</th>
              <td>Dealer purchase</td>
              <td>Marketplace</td>
              <td class="is-win">AutoDNA</td>
            </tr>
            <tr>
              <th scope="row">Features</th>
              <td>Higher price, GST extra</td>
              <td>Lower price</td>
              <td class="is-win">Full inspection completed, 3-year paid warranty, financing available</td>
            </tr>
            <tr>
              <th scope="row">Cons</th>
              <td>—</td>
              <td>Car not inspected, potential issues, no warranty</td>
              <td class="is-win">None — all value included</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <!-- ══ 5. STATS ══════════════════════════════════════════════════════ -->
  <section class="stats" id="stats">
    <div class="shell">
      <div class="stats__grid">
        <article class="stat">
          <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
          <span class="stat__num">200+</span>
          <h2 class="stat__title">Stages of inspection</h2>
          <p class="stat__text">We test, verify, and only then hand over the keys. Real inspection — not intuition.</p>
        </article>

        <article class="stat">
          <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
          <span class="stat__num">450+</span>
          <h2 class="stat__title">Clients said “Wow!”</h2>
          <p class="stat__text">And new ones join every week. Every car is a story — and our client is always the main character.</p>
        </article>

        <article class="stat">
          <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
          <span class="stat__num">15+</span>
          <h2 class="stat__title">Years in the industry</h2>
          <p class="stat__text">We’ve seen it all — and that’s why we do it right. It’s in our DNA.</p>
        </article>

        <article class="stat">
          <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
          <span class="stat__num">2–4</span>
          <h2 class="stat__title">Weeks — faster than you expect</h2>
          <p class="stat__text">An optimized process — no delays, no surprises. Search, preparation, and the car is yours.</p>
        </article>
      </div>
    </div>
  </section>

  <!-- ══ 6. PARENT CORPORATION ═════════════════════════════════════════ -->
  <section class="parent" id="parent">
    <div class="parent__outline" aria-hidden="true"></div>

    <div class="shell">
      <div class="parent__row">
        <p class="sec-claim parent__claim">AutoDNA is the parent corporation that brings together SkipTheDealer, AutoDNA Service, and other companies.</p>
        <div class="parent__aside">
          <p class="sec-claim">We play by new rules — and this is just the beginning.</p>
        </div>
      </div>

      <img class="parent__photo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/showroom.webp" alt="The AutoDNA showroom at night" loading="lazy">

      <p class="sec-claim parent__plan">Over the next two years, we plan to create a complete automotive hub for car enthusiasts, offering all kinds of services and entertainment for our clients.</p>
    </div>
  </section>

  <!-- ══ 7. SERVICES — the band from the board ═════════════════════════ -->
  <section class="svc" id="services" aria-label="Our services">
    <div class="svc__stage">
      <img class="svc__bg is-active" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/svc-skip.webp"    alt="" data-state="skip" aria-hidden="false">
      <img class="svc__bg"           src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/svc-flip.webp"    alt="" data-state="flip" aria-hidden="true">
      <img class="svc__bg"           src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/svc-service.webp" alt="" data-state="service" aria-hidden="true">

      <h2 class="svc__word">Services</h2>

      <div class="svc__zones">
        <a class="svc__zone" href="#skip"    data-zone="skip"    aria-label="SkipTheDealers"></a>
        <a class="svc__zone" href="#flip"    data-zone="flip"    aria-label="AutoDNA Flip"></a>
        <a class="svc__zone" href="#service" data-zone="service" aria-label="AutoDNA Service"></a>
      </div>

      <div class="svc__cards">
        <a class="svc__card" href="#skip" data-card="skip">
          <span class="svc__corner" aria-hidden="true"></span><span class="svc__corner" aria-hidden="true"></span><span class="svc__corner" aria-hidden="true"></span><span class="svc__corner" aria-hidden="true"></span>
          <span class="svc__label">SkipTheDealers</span>
          <span class="svc__desc">Find, bid, and buy the best vehicles directly from trusted car auctions. Smart, transparent, and hassle-free — we handle the process from search to delivery.</span>
          <span class="svc__go" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 17 17 7M9 7h8v8" stroke-linecap="square"/></svg></span>
        </a>

        <a class="svc__card" href="#flip" data-card="flip">
          <span class="svc__corner" aria-hidden="true"></span><span class="svc__corner" aria-hidden="true"></span><span class="svc__corner" aria-hidden="true"></span><span class="svc__corner" aria-hidden="true"></span>
          <span class="svc__label">AutoDNA Flip</span>
          <span class="svc__desc">Turn vehicles into valuable assets. We help you invest wisely in high-demand cars and maximize your returns through strategic resale.</span>
          <span class="svc__go" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 17 17 7M9 7h8v8" stroke-linecap="square"/></svg></span>
        </a>

        <a class="svc__card" href="#service" data-card="service">
          <span class="svc__corner" aria-hidden="true"></span><span class="svc__corner" aria-hidden="true"></span><span class="svc__corner" aria-hidden="true"></span><span class="svc__corner" aria-hidden="true"></span>
          <span class="svc__label">AutoDNA Service</span>
          <span class="svc__desc">A next-generation automotive centre: PaintBot robotics, SkipTheShop concierge and DriveCarePlan telematics under one roof.</span>
          <span class="svc__go" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 17 17 7M9 7h8v8" stroke-linecap="square"/></svg></span>
        </a>
      </div>
    </div>
  </section>

  <!-- ══ 8. AUTO CLUB ═════════════════════════════════════════════════-->
  <section class="club" id="club">
    <div class="shell">
      <p class="sec-claim club__head">Join DNA Auto Club and get more than just service.</p>
    </div>

    <p class="club__word" aria-hidden="true">AutoClub</p>

    <div class="club__grid">
      <article class="club-card">
        <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
        <h2 class="club-card__name">Service</h2>
        <span class="club-card__deal">
          <span class="club-card__num">30%</span>
          <span class="club-card__num club-card__num--accent">off any work.</span>
        </span>
        <p class="club-card__text">The lowest prices in Calgary for bodywork, mechanics, and painting.</p>
      </article>

      <article class="club-card">
        <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
        <h2 class="club-card__name">Carwash</h2>
        <span class="club-card__deal">
          <span class="club-card__num club-card__num--accent">Every second wash</span>
          <span class="club-card__num">is free</span>
        </span>
        <p class="club-card__text">Modern automatic carwash that preserves your car’s coating.</p>
      </article>

      <article class="club-card">
        <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
        <h2 class="club-card__name">Wheel alignment</h2>
        <span class="club-card__deal">
          <span class="club-card__num">$70</span>
          <span class="club-card__was">market price $150</span>
        </span>
        <p class="club-card__text">State-of-the-art equipment with automatic adjustment.</p>
      </article>

      <article class="club-card">
        <span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span><span class="corner-mark"></span>
        <h2 class="club-card__name">Tire change</h2>
        <span class="club-card__deal">
          <span class="club-card__num">$60</span>
          <span class="club-card__was">market price $120</span>
        </span>
        <p class="club-card__text">Any wheel repair, seasonal tire replacement, and free tire storage.</p>
      </article>
    </div>

    <div class="shell">
      <p class="sec-claim club__claim">Real benefits, real savings —<br>made for drivers like you.</p>
    </div>
  </section>

  <!-- ══ 9. COMMUNITY ═════════════════════════════════════════════════ -->
  <section class="community" id="truth">
    <div class="shell">
      <div class="community__inner">
        <h2 class="community__word">We don’t<br><em>just</em><br>sell<br>cars.</h2>

        <div>
          <img class="community__photo" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/community.webp" alt="The AutoDNA team in front of a row of cars" loading="lazy">
        </div>
      </div>

      <p class="sec-claim community__claim">We’re building a community where every customer gets more than they expect.</p>
    </div>
  </section>

  <!-- ══ 10. FOOTER ═══════════════════════════════════════════════════ -->
</main>

<?php
get_footer();
